BUILD OPTIONS
A) Android Studio: File > Open this folder, then Build > Build APK(s).
B) No install: upload this folder to a new GitHub repo. Actions tab > "Build APK" > download the artifact (app-debug.apk).
Then copy the APK to your phone and allow "install unknown apps".
